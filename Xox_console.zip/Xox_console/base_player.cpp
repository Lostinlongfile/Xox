#include "base_player.h"

base_player::base_player()
{
    //ctor
}
